package Proyecto;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

public class VentanaIniciarSesión extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtUsuario;
    private JPasswordField txtContraseña;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VentanaIniciarSesión frame = new VentanaIniciarSesión();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VentanaIniciarSesión() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 652, 476);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblIniciarSesion = new JLabel("Iniciar Sesión");
        lblIniciarSesion.setForeground(new Color(255, 255, 255));
        lblIniciarSesion.setFont(new Font("Tahoma", Font.BOLD, 40));
        lblIniciarSesion.setBounds(47, 42, 354, 74);
        contentPane.add(lblIniciarSesion);

        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setForeground(new Color(255, 255, 255));
        lblUsuario.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblUsuario.setBounds(45, 162, 113, 35);
        contentPane.add(lblUsuario);

        JLabel lblContraseña = new JLabel("Contraseña");
        lblContraseña.setForeground(new Color(255, 255, 255));
        lblContraseña.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblContraseña.setBounds(26, 222, 129, 35);
        contentPane.add(lblContraseña);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(168, 173, 100, 20);
        contentPane.add(txtUsuario);
        txtUsuario.setColumns(10);

        txtContraseña = new JPasswordField();
        txtContraseña.setBounds(168, 233, 100, 20);
        contentPane.add(txtContraseña);
        
        JButton btnNewButton = new JButton("Salir");
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton.setBounds(445, 234, 89, 23);
        contentPane.add(btnNewButton);
        
        btnNewButton.addActionListener(e -> {
            new VentanaPrincipal().setVisible(true); // Abre VentanaPrincipal
            dispose(); // Cierra la ventana actual
        });

        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnEntrar.setBounds(412, 124, 155, 58);
        contentPane.add(btnEntrar);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(VentanaIniciarSesión.class.getResource("/imagen/campoo.jpeg")));
        lblNewLabel.setBounds(0, 0, 636, 437);
        contentPane.add(lblNewLabel);
        
        btnEntrar.addActionListener(e -> {
            String usuario = txtUsuario.getText().trim();
            String contraseña = new String(txtContraseña.getPassword()).trim();

            if (usuario.equals("carlos") && contraseña.equals("1234")) {
                new FiltroMultiple(); // Abre la ventana de filtros
                dispose();            // Cierra la ventana de login
            } else {
                JOptionPane.showMessageDialog(this,
                    "Usuario o contraseña incorrectos. Intenta de nuevo.",
                    "Error de autenticación",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
