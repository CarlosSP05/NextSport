package Proyecto;

/**
 * Clase que representa un producto con sus atributos básicos como
 * id, nombre, marca, modelo, talla, color, precio y cantidad en stock.
 */
public class Producto {
    private int id;
    private String nombre;
    private String marca;
    private String modelo;
    private String talla;
    private String color;
    private double precio;
    private int cantidadStock;

    /**
     * Constructor de la clase Producto.
     * 
     * @param id            Identificador único del producto.
     * @param nombre        Nombre del producto.
     * @param marca         Marca del producto.
     * @param modelo        Modelo del producto.
     * @param talla         Talla del producto.
     * @param color         Color del producto.
     * @param precio        Precio del producto.
     * @param cantidadStock Cantidad disponible en stock.
     */
    public Producto(int id, String nombre, String marca, String modelo, String talla, String color, double precio, int cantidadStock) {
        this.id = id;
        this.nombre = nombre;
        this.marca = marca;
        this.modelo = modelo;
        this.talla = talla;
        this.color = color;
        this.precio = precio;
        this.cantidadStock = cantidadStock;
    }

    /**
     * Obtiene el id del producto.
     * 
     * @return El id del producto.
     */
    public int getId() { return id; }

    /**
     * Establece el id del producto.
     * 
     * @param id El nuevo id del producto.
     */
    public void setId(int id) { this.id = id; }

    /**
     * Obtiene el nombre del producto.
     * 
     * @return El nombre del producto.
     */
    public String getNombre() { return nombre; }

    /**
     * Establece el nombre del producto.
     * 
     * @param nombre El nuevo nombre del producto.
     */
    public void setNombre(String nombre) { this.nombre = nombre; }

    /**
     * Obtiene la marca del producto.
     * 
     * @return La marca del producto.
     */
    public String getMarca() { return marca; }

    /**
     * Establece la marca del producto.
     * 
     * @param marca La nueva marca del producto.
     */
    public void setMarca(String marca) { this.marca = marca; }

    /**
     * Obtiene el modelo del producto.
     * 
     * @return El modelo del producto.
     */
    public String getModelo() { return modelo; }

    /**
     * Establece el modelo del producto.
     * 
     * @param modelo El nuevo modelo del producto.
     */
    public void setModelo(String modelo) { this.modelo = modelo; }

    /**
     * Obtiene la talla del producto.
     * 
     * @return La talla del producto.
     */
    public String getTalla() { return talla; }

    /**
     * Establece la talla del producto.
     * 
     * @param talla La nueva talla del producto.
     */
    public void setTalla(String talla) { this.talla = talla; }

    /**
     * Obtiene el color del producto.
     * 
     * @return El color del producto.
     */
    public String getColor() { return color; }

    /**
     * Establece el color del producto.
     * 
     * @param color El nuevo color del producto.
     */
    public void setColor(String color) { this.color = color; }

    /**
     * Obtiene el precio del producto.
     * 
     * @return El precio del producto.
     */
    public double getPrecio() { return precio; }

    /**
     * Establece el precio del producto.
     * 
     * @param precio El nuevo precio del producto.
     */
    public void setPrecio(double precio) { this.precio = precio; }

    /**
     * Obtiene la cantidad disponible en stock del producto.
     * 
     * @return La cantidad en stock.
     */
    public int getCantidadStock() { return cantidadStock; }

    /**
     * Establece la cantidad disponible en stock del producto.
     * 
     * @param cantidadStock La nueva cantidad en stock.
     */
    public void setCantidadStock(int cantidadStock) { this.cantidadStock = cantidadStock; }

    /**
     * Representa el producto como una cadena de texto con sus principales características.
     * 
     * @return Una descripción en formato string del producto.
     */
    @Override
    public String toString() {
        return nombre + " (" + marca + " " + modelo + ", " + color + ", Talla: " + talla + ")";
    }
}


