package Proyecto;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.*;

public class VentanaUsuario extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textNombre;
	private JTextField textApellidos;
	private JTextField textDireccion;
	private JTextField textTelefono;
	private JTextField textCorreo;
	private JButton btnEnviar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				VentanaUsuario frame = new VentanaUsuario();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaUsuario() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 745, 478);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblTitulo = new JLabel("Registrarse");
		lblTitulo.setForeground(new Color(255, 255, 255));
		lblTitulo.setFont(new Font("Trebuchet MS", Font.BOLD, 50));
		lblTitulo.setBounds(38, 11, 293, 94);
		contentPane.add(lblTitulo);

		JLabel lblInstrucciones = new JLabel("Introduce tus datos:");
		lblInstrucciones.setForeground(new Color(255, 255, 255));
		lblInstrucciones.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblInstrucciones.setBounds(48, 98, 310, 26);
		contentPane.add(lblInstrucciones);

		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setForeground(new Color(255, 255, 255));
		lblNombre.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombre.setBounds(26, 141, 188, 37);
		contentPane.add(lblNombre);

		JLabel lblApellidos = new JLabel("Apellidos");
		lblApellidos.setForeground(new Color(255, 255, 255));
		lblApellidos.setHorizontalAlignment(SwingConstants.CENTER);
		lblApellidos.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblApellidos.setBounds(26, 189, 188, 37);
		contentPane.add(lblApellidos);

		JLabel lblDireccion = new JLabel("Dirección");
		lblDireccion.setForeground(new Color(255, 255, 255));
		lblDireccion.setHorizontalAlignment(SwingConstants.CENTER);
		lblDireccion.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblDireccion.setBounds(26, 248, 188, 37);
		contentPane.add(lblDireccion);

		JLabel lblTelefono = new JLabel("Teléfono");
		lblTelefono.setForeground(new Color(255, 255, 255));
		lblTelefono.setHorizontalAlignment(SwingConstants.CENTER);
		lblTelefono.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblTelefono.setBounds(26, 305, 188, 37);
		contentPane.add(lblTelefono);

		JLabel lblCorreo = new JLabel("Correo electrónico");
		lblCorreo.setForeground(new Color(255, 255, 255));
		lblCorreo.setHorizontalAlignment(SwingConstants.CENTER);
		lblCorreo.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblCorreo.setBounds(10, 353, 244, 37);
		contentPane.add(lblCorreo);

		textNombre = new JTextField();
		textNombre.setBounds(215, 149, 142, 33);
		contentPane.add(textNombre);

		textApellidos = new JTextField();
		textApellidos.setBounds(215, 189, 142, 33);
		contentPane.add(textApellidos);

		textDireccion = new JTextField();
		textDireccion.setBounds(215, 248, 142, 33);
		contentPane.add(textDireccion);

		textTelefono = new JTextField();
		textTelefono.setBounds(215, 309, 142, 33);
		contentPane.add(textTelefono);

		textCorreo = new JTextField();
		textCorreo.setBounds(275, 357, 142, 33);
		contentPane.add(textCorreo);

		JButton btnSalir = new JButton("Salir");
		btnSalir.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSalir.setBounds(587, 374, 89, 23);
		btnSalir.addActionListener(e -> {
			VentanaPrincipal ventana = new VentanaPrincipal();
			ventana.setVisible(true);
			dispose();
		});
		contentPane.add(btnSalir);

		btnEnviar = new JButton("Enviar");
		btnEnviar.setFont(new Font("Tw Cen MT", Font.BOLD, 20));
		btnEnviar.setBounds(587, 326, 114, 41);
		btnEnviar.setEnabled(false); // desactivado por defecto
		btnEnviar.addActionListener(e -> {
			VentanaRegistrado ventanaRegistrado = new VentanaRegistrado();
			ventanaRegistrado.setVisible(true);
			dispose();
		});
		contentPane.add(btnEnviar);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(VentanaUsuario.class.getResource("/imagen/campoo.jpeg")));
		lblNewLabel.setBounds(0, 0, 729, 439);
		contentPane.add(lblNewLabel);

		// Escuchadores para habilitar o deshabilitar el botón
		DocumentListener listener = new DocumentListener() {
			public void insertUpdate(DocumentEvent e) { verificarCampos(); }
			public void removeUpdate(DocumentEvent e) { verificarCampos(); }
			public void changedUpdate(DocumentEvent e) { verificarCampos(); }
		};

		textNombre.getDocument().addDocumentListener(listener);
		textApellidos.getDocument().addDocumentListener(listener);
		textDireccion.getDocument().addDocumentListener(listener);
		textTelefono.getDocument().addDocumentListener(listener);
		textCorreo.getDocument().addDocumentListener(listener);
	}

	private void verificarCampos() {
		boolean habilitar = !textNombre.getText().trim().isEmpty() &&
		                    !textApellidos.getText().trim().isEmpty() &&
		                    !textDireccion.getText().trim().isEmpty() &&
		                    !textTelefono.getText().trim().isEmpty() &&
		                    !textCorreo.getText().trim().isEmpty();

		btnEnviar.setEnabled(habilitar);
	}
}

