package Proyecto;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.*;

/**
 * Clase que representa una ventana gráfica (JFrame) que muestra
 * las zapatillas más vendidas con imágenes y etiquetas.
 */
public class TopVentas extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Método principal que inicia la aplicación y muestra la ventana TopVentas.
     * 
     * @param args Argumentos de línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    TopVentas frame = new TopVentas();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Constructor que configura la ventana TopVentas, inicializando componentes
     * visuales como etiquetas, botones e imágenes.
     */
    public TopVentas() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 641, 485);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Las más vendidas");
        lblNewLabel.setForeground(Color.WHITE);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
        lblNewLabel.setBounds(214, 11, 230, 36);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("1. Adidas X Speedportal");
        lblNewLabel_1.setForeground(Color.WHITE);
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        lblNewLabel_1.setBounds(98, 66, 173, 14);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("2. Adidas Predator Freak");
        lblNewLabel_2.setForeground(Color.WHITE);
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
        lblNewLabel_2.setBounds(373, 67, 173, 14);
        contentPane.add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("3. Puma Future Pro");
        lblNewLabel_3.setForeground(Color.WHITE);
        lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
        lblNewLabel_3.setBounds(46, 246, 139, 14);
        contentPane.add(lblNewLabel_3);

        JLabel lblNewLabel_4 = new JLabel("4. Nike Mercurial Vapor");
        lblNewLabel_4.setForeground(Color.WHITE);
        lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
        lblNewLabel_4.setBounds(251, 247, 151, 14);
        contentPane.add(lblNewLabel_4);

        JLabel lblNewLabel_5 = new JLabel("5. Nike Phantom GT2");
        lblNewLabel_5.setForeground(Color.WHITE);
        lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
        lblNewLabel_5.setBounds(462, 247, 153, 14);
        contentPane.add(lblNewLabel_5);

        JButton btnNewButton = new JButton("Salir");
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton.setBounds(286, 423, 89, 23);
        contentPane.add(btnNewButton);

        // Acción del botón "Salir"
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FiltroMultiple filtroFrame = new FiltroMultiple();
                filtroFrame.setVisible(true);
                dispose(); // Cierra esta ventana
            }
        });

        JLabel lblNewLabel_6 = new JLabel("");
        lblNewLabel_6.setBounds(73, 92, 208, 130);
        ImageIcon icono2 = new ImageIcon(TopVentas.class.getResource("/imagen/X Speedportal.jpg"));
        Image imagen2 = icono2.getImage().getScaledInstance(lblNewLabel_6.getWidth(), lblNewLabel_6.getHeight(), Image.SCALE_SMOOTH);
        lblNewLabel_6.setIcon(new ImageIcon(imagen2));
        contentPane.add(lblNewLabel_6);

        JLabel lblNewLabel_7 = new JLabel("");
        lblNewLabel_7.setBounds(348, 93, 220, 129);
        ImageIcon icono3 = new ImageIcon(TopVentas.class.getResource("/imagen/freak.jpg"));
        Image imagen3 = icono3.getImage().getScaledInstance(lblNewLabel_7.getWidth(), lblNewLabel_7.getHeight(), Image.SCALE_SMOOTH);
        lblNewLabel_7.setIcon(new ImageIcon(imagen3));
        contentPane.add(lblNewLabel_7);

        JLabel lblNewLabel_8 = new JLabel("");
        lblNewLabel_8.setBounds(20, 271, 180, 148);
        ImageIcon icono4 = new ImageIcon(TopVentas.class.getResource("/imagen/futurepro.jpg"));
        Image imagen4 = icono4.getImage().getScaledInstance(lblNewLabel_8.getWidth(), lblNewLabel_8.getHeight(), Image.SCALE_SMOOTH);
        lblNewLabel_8.setIcon(new ImageIcon(imagen4));
        contentPane.add(lblNewLabel_8);

        JLabel lblNewLabel_9 = new JLabel("");
        lblNewLabel_9.setBounds(235, 278, 180, 141);
        ImageIcon icono5 = new ImageIcon(TopVentas.class.getResource("/imagen/vapor.jpg"));
        Image imagen5 = icono5.getImage().getScaledInstance(lblNewLabel_9.getWidth(), lblNewLabel_9.getHeight(), Image.SCALE_SMOOTH);
        lblNewLabel_9.setIcon(new ImageIcon(imagen5));
        contentPane.add(lblNewLabel_9);

        JLabel lblNewLabel_10 = new JLabel("");
        lblNewLabel_10.setBounds(442, 271, 173, 148);
        ImageIcon icono6 = new ImageIcon(TopVentas.class.getResource("/imagen/gt2.jpg"));
        Image imagen6 = icono6.getImage().getScaledInstance(lblNewLabel_10.getWidth(), lblNewLabel_10.getHeight(), Image.SCALE_SMOOTH);
        lblNewLabel_10.setIcon(new ImageIcon(imagen6));
        contentPane.add(lblNewLabel_10);

        JLabel lblNewLabel_11 = new JLabel("");
        lblNewLabel_11.setBounds(0, 0, 625, 446);
        ImageIcon icono7 = new ImageIcon(TopVentas.class.getResource("/imagen/negrofondo.jpg"));
        Image imagen7 = icono7.getImage().getScaledInstance(lblNewLabel_11.getWidth(), lblNewLabel_11.getHeight(), Image.SCALE_SMOOTH);
        lblNewLabel_11.setIcon(new ImageIcon(imagen7));
        contentPane.add(lblNewLabel_11);
    }
}


