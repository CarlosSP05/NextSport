package Proyecto;

import java.sql.Connection;
import java.sql.SQLException;

public class BD {

	public static Connection conectar() {
	try {
		ConexionMySQL conexion = new ConexionMySQL("root","","nextsport");
		
		conexion.conectar();
		
		return conexion.getConnection();
	} catch (SQLException e)
	{
		System.out.println("Error al conectar");
		e.printStackTrace();
		return null;
	}

	}

}
