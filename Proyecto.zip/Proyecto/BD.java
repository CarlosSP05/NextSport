package Proyecto;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Clase de utilidad para obtener una conexión a la base de datos MySQL.
 * 
 * <p>Usa la clase {@link ConexionMySQL} para establecer la conexión con la base de datos
 * "nextsport" con usuario "root" y contraseña vacía.</p>
 * 
 * <p>Ejemplo de uso:
 * <pre>{@code
 * Connection conn = BD.conectar();
 * if (conn != null) {
 *     // usar conexión
 * }
 * }</pre></p>
 * 
 * @author 
 * @version 1.0
 */
public class BD {

    /**
     * Establece y retorna una conexión a la base de datos.
     * 
     * @return Un objeto {@link Connection} si la conexión fue exitosa, o {@code null} si ocurrió un error.
     */
    public static Connection conectar() {
        try {
            ConexionMySQL conexion = new ConexionMySQL("root", "", "nextsport"); // Crea una instancia de conexión
            conexion.conectar();  // Intenta conectarse
            return conexion.getConnection(); // Devuelve la conexión activa
        } catch (SQLException e) {
            System.out.println("Error al conectar"); // Imprime error en consola
            e.printStackTrace(); // Detalles del error
            return null; // Si hay error, retorna null
        }
    }
}

