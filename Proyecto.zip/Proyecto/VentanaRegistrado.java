package Proyecto;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

/**
 * Clase que representa la ventana que muestra un mensaje de registro exitoso
 * y permite al usuario ingresar sus datos para acceder al sistema.
 */
public class VentanaRegistrado extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtUsuario;
    private JPasswordField txtContraseña;

    /**
     * Método principal que inicia la aplicación mostrando la ventana de registro exitoso.
     * 
     * @param args Argumentos de línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VentanaRegistrado frame = new VentanaRegistrado();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Constructor que configura la ventana, inicializa y posiciona los componentes gráficos,
     * así como la acción del botón para validar el usuario y contraseña.
     */
    public VentanaRegistrado() {
        setTitle("Usuario Registrado");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 652, 476);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitulo = new JLabel("¡Registrado Correctamente!");
        lblTitulo.setForeground(new Color(255, 255, 255));
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblTitulo.setBounds(10, 28, 377, 63);
        contentPane.add(lblTitulo);

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setForeground(new Color(255, 255, 255));
        lblUsuario.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblUsuario.setBounds(42, 165, 100, 25);
        contentPane.add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(152, 168, 180, 25);
        contentPane.add(txtUsuario);
        txtUsuario.setColumns(10);

        JLabel lblContraseña = new JLabel("Contraseña:");
        lblContraseña.setForeground(new Color(255, 255, 255));
        lblContraseña.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblContraseña.setBounds(20, 250, 134, 25);
        contentPane.add(lblContraseña);

        txtContraseña = new JPasswordField();
        txtContraseña.setBounds(152, 253, 180, 25);
        contentPane.add(txtContraseña);

        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnEntrar.setBounds(411, 291, 180, 50);
        contentPane.add(btnEntrar);
        
        // Acción para validar usuario y contraseña al pulsar "Entrar"
        btnEntrar.addActionListener(e -> {
            String usuario = txtUsuario.getText().trim();
            String contraseña = new String(txtContraseña.getPassword()).trim();

            if (usuario.equals("jesús") && contraseña.equals("1234")) {
                new FiltroMultiple(); // Abre la ventana de filtros
                dispose();            // Cierra esta ventana
            } else {
                JOptionPane.showMessageDialog(this,
                    "Usuario o contraseña incorrectos. Intenta de nuevo.",
                    "Error de autenticación",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JLabel lblNewLabel = new JLabel("Introduce tus datos para acceder");
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNewLabel.setBounds(20, 102, 314, 25);
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setIcon(new ImageIcon(VentanaRegistrado.class.getResource("/imagen/campoo.jpeg")));
        lblNewLabel_1.setBounds(0, 0, 636, 437);
        contentPane.add(lblNewLabel_1);
    }
}



