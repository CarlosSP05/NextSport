package Proyecto;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class FiltroMultiple extends JFrame {

    public FiltroMultiple() {
        setTitle("Filtro de Botas de Fútbol");
        setSize(1000, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnas = {"Talla", "Color", "Marca", "Modelo", "Precio", "Stock"};
        Object[][] datos = {
            {"39", "Rojo", "Nike", "Phantom GX", 120.00, 5},
            {"40", "Negro", "Adidas", "Predator Edge", 130.00, 3},
            {"41", "Blanco", "Puma", "Future Z", 110.00, 7},
            {"42", "Rojo", "Nike", "Mercurial Vapor", 125.00, 2},
            {"43", "Negro", "Adidas", "X Speedportal", 135.00, 0},
            {"39", "Blanco", "Puma", "Ultra Ultimate", 105.00, 4},
            {"40", "Azul", "Nike", "Tiempo Legend", 115.00, 6},
            {"41", "Verde", "Adidas", "Copa Pure", 128.00, 5},
            {"42", "Naranja", "Puma", "Future Pro", 112.00, 3},
            {"43", "Blanco", "Nike", "Air Zoom Mercurial", 140.00, 4},
            {"39", "Negro", "Adidas", "Nemeziz+", 122.00, 2},
            {"40", "Gris", "Puma", "King Platinum", 118.00, 6},
            {"41", "Rojo", "Nike", "Phantom Luna", 126.00, 5},
            {"42", "Blanco", "Adidas", "Predator Accuracy", 132.00, 3},
            {"43", "Azul", "Puma", "Ultra Match", 107.00, 7},
            {"39", "Amarillo", "Nike", "Phantom Venom", 119.00, 4},
            {"40", "Gris", "Adidas", "X Ghosted", 134.00, 2},
            {"41", "Verde", "Puma", "One 5.1", 111.00, 6},
            {"42", "Azul", "Nike", "Superfly 8", 138.00, 3},
            {"43", "Naranja", "Adidas", "Copa Mundial", 125.00, 4},
            {"39", "Rojo", "Puma", "Future Ultimate", 109.00, 5},
            {"40", "Negro", "Nike", "Tiempo React", 117.00, 2},
            {"41", "Blanco", "Adidas", "Predator Freak", 133.00, 1},
            {"42", "Amarillo", "Puma", "King Top", 113.00, 6},
            {"43", "Verde", "Nike", "Phantom GT2", 124.00, 2},
            {"39", "Azul", "Adidas", "X Crazyfast", 137.00, 5},
            {"40", "Gris", "Puma", "Ultra 1.4", 106.00, 7},
            {"41", "Rojo", "Nike", "Mercurial Dream Speed", 129.00, 3},
            {"42", "Blanco", "Adidas", "Copa Sense", 127.00, 2},
            {"43", "Negro", "Puma", "Future Play", 108.00, 6}
        };

        JTable tabla = new JTable(new DefaultTableModel(datos, columnas));
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(tabla.getModel());
        tabla.setRowSorter(sorter);

        JPanel panelFiltros = new JPanel(new GridLayout(2, columnas.length));
        panelFiltros.setBounds(0, 0, 984, 0);
        List<JTextField> camposFiltro = new ArrayList<>();

        for (String columna : columnas) {
            panelFiltros.add(new JLabel("Filtrar por " + columna));
        }

        for (int i = 0; i < columnas.length; i++) {
            JTextField campo = new JTextField();
            camposFiltro.add(campo);
            panelFiltros.add(campo);

            final int col = i;
            campo.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                public void insertUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltros(sorter, camposFiltro); }
                public void removeUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltros(sorter, camposFiltro); }
                public void changedUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltros(sorter, camposFiltro); }
            });
        }

        getContentPane().setLayout(null);
        getContentPane().add(panelFiltros);

        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBounds(0, 0, 984, 428);
        getContentPane().add(scrollPane);

        // Panel para los botones
        JPanel panelBoton = new JPanel();
        panelBoton.setBounds(0, 428, 984, 33);
        panelBoton.setLayout(null);

        JButton btnSalir = new JButton("Salir");
        btnSalir.setBounds(844, 6, 89, 23);
        btnSalir.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                VentanaPrincipal ventana = new VentanaPrincipal(); // Abre VentanaPrincipal
                ventana.setVisible(true);
                dispose(); // Cierra esta ventana
            }
        });
        panelBoton.add(btnSalir);

        JButton btnTopVentas = new JButton("Top 5 ventas");
        btnTopVentas.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnTopVentas.setBounds(410, 6, 137, 23);

        // Aquí agregamos la acción para abrir TopVentas
        btnTopVentas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TopVentas topVentas = new TopVentas(); // Abrimos TopVentas
                topVentas.setVisible(true);
                dispose(); // Cerramos esta ventana
            }
        });

        panelBoton.add(btnTopVentas);
        getContentPane().add(panelBoton);

        setVisible(true);
    }

    private void aplicarFiltros(TableRowSorter<TableModel> sorter, List<JTextField> campos) {
        List<RowFilter<Object, Object>> filtros = new ArrayList<>();

        for (int i = 0; i < campos.size(); i++) {
            String texto = campos.get(i).getText();
            if (!texto.trim().isEmpty()) {
                filtros.add(RowFilter.regexFilter("(?i)" + Pattern.quote(texto), i));
            }
        }

        sorter.setRowFilter(RowFilter.andFilter(filtros));
    }
}




