package Proyecto;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class FiltroMultiple extends JFrame {

    public FiltroMultiple() {
        setTitle("Filtro de Botas de Fútbol");
        setSize(1000, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnas = {"Talla", "Color", "Marca", "Modelo", "Precio", "Stock"};

        // Carga datos desde la base de datos
        Object[][] datos = cargarDatosDesdeBD();

        // Crea la tabla y el sorter para filtros
        JTable tabla = new JTable(new DefaultTableModel(datos, columnas));
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(tabla.getModel());
        tabla.setRowSorter(sorter);

        // Panel de filtros
        JPanel panelFiltros = new JPanel(new GridLayout(2, columnas.length));
        List<JTextField> camposFiltro = new ArrayList<>();

        for (String columna : columnas) {
            panelFiltros.add(new JLabel("Filtrar por " + columna));
        }

        for (int i = 0; i < columnas.length; i++) {
            JTextField campo = new JTextField();
            camposFiltro.add(campo);
            panelFiltros.add(campo);

            final int col = i;
            campo.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                public void insertUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltros(sorter, camposFiltro); }
                public void removeUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltros(sorter, camposFiltro); }
                public void changedUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltros(sorter, camposFiltro); }
            });
        }

        getContentPane().setLayout(null);
        panelFiltros.setBounds(0, 0, 984, 50);
        getContentPane().add(panelFiltros);

        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBounds(0, 50, 984, 370);
        getContentPane().add(scrollPane);

        // Panel para botones
        JPanel panelBoton = new JPanel();
        panelBoton.setBounds(0, 420, 984, 33);
        panelBoton.setLayout(null);

        JButton btnSalir = new JButton("Salir");
        btnSalir.setBounds(844, 6, 89, 23);
        btnSalir.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                VentanaPrincipal ventana = new VentanaPrincipal();
                ventana.setVisible(true);
                dispose();
            }
        });
        panelBoton.add(btnSalir);

        JButton btnTopVentas = new JButton("Top 5 ventas");
        btnTopVentas.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnTopVentas.setBounds(410, 6, 137, 23);
        btnTopVentas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TopVentas topVentas = new TopVentas();
                topVentas.setVisible(true);
                dispose();
            }
        });
        panelBoton.add(btnTopVentas);

        getContentPane().add(panelBoton);

        setVisible(true);
    }

    private void aplicarFiltros(TableRowSorter<TableModel> sorter, List<JTextField> campos) {
        List<RowFilter<Object, Object>> filtros = new ArrayList<>();

        for (int i = 0; i < campos.size(); i++) {
            String texto = campos.get(i).getText();
            if (!texto.trim().isEmpty()) {
                filtros.add(RowFilter.regexFilter("(?i)" + Pattern.quote(texto), i));
            }
        }

        sorter.setRowFilter(RowFilter.andFilter(filtros));
    }

    private Object[][] cargarDatosDesdeBD() {
        ArrayList<Object[]> filas = new ArrayList<>();

        Connection conn = BD.conectar();  // Usa tu clase BD para conectar
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return new Object[0][0];
        }

        String consulta = "SELECT talla, color, marca, modelo, precio, cantidadStock FROM nextsport";

        try (PreparedStatement stmt = conn.prepareStatement(consulta);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Object[] fila = new Object[6];
                fila[0] = rs.getString("talla");
                fila[1] = rs.getString("color");
                fila[2] = rs.getString("marca");
                fila[3] = rs.getString("modelo");
                fila[4] = rs.getDouble("precio");
                fila[5] = rs.getInt("cantidadStock");
                filas.add(fila);
            }
            conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
            e.printStackTrace();
            return new Object[0][0];
        }

        Object[][] datos = new Object[filas.size()][6];
        for (int i = 0; i < filas.size(); i++) {
            datos[i] = filas.get(i);
        }
        return datos;
    }
}





