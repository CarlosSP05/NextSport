package Test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

public class FiltroMultipleTest {

    private JTable tabla;
    private JTextField[] camposFiltro;

    @BeforeEach
    public void setUp() {
        // Columnas y datos simulados
        String[] columnas = {"Talla", "Color", "Marca", "Modelo", "Precio", "Stock"};
        Object[][] datos = {
            {"40", "Rojo", "Nike", "AirMax", 120.0, 15},
            {"41", "Azul", "Adidas", "RunFast", 100.0, 8},
            {"42", "Rojo", "Puma", "Speed", 95.0, 12}
        };

        // Crear tabla
        DefaultTableModel modelo = new DefaultTableModel(datos, columnas);
        tabla = new JTable(modelo);

        // Crear campos de filtro como lo hace FiltroMultiple
        camposFiltro = new JTextField[columnas.length];
        for (int i = 0; i < columnas.length; i++) {
            camposFiltro[i] = new JTextField();
        }

        // Simular entrada del usuario
        camposFiltro[1].setText("Rojo");

        // Aplicar filtro
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(tabla.getModel());
        List<RowFilter<Object, Object>> filtros = new ArrayList<>();

        for (int i = 0; i < camposFiltro.length; i++) {
            String texto = camposFiltro[i].getText();
            if (!texto.trim().isEmpty()) {
                filtros.add(RowFilter.regexFilter("(?i)" + Pattern.quote(texto), i));
            }
        }

        sorter.setRowFilter(RowFilter.andFilter(filtros));
        tabla.setRowSorter(sorter);
    }

    @Test
    public void testFiltradoRojo() {
        TableRowSorter sorter = (TableRowSorter) tabla.getRowSorter();
        assertNotNull(sorter);
        assertEquals(2, sorter.getViewRowCount());

        // Verificar que las filas visibles tienen "Rojo"
        for (int i = 0; i < sorter.getViewRowCount(); i++) {
            int modelRow = sorter.convertRowIndexToModel(i);
            assertEquals("Rojo", tabla.getModel().getValueAt(modelRow, 1));
        }
    }
}


