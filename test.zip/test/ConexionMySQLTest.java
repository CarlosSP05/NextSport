package Test;

import Proyecto.ConexionMySQL;
import org.junit.jupiter.api.Test;
import java.sql.Connection;
import java.sql.SQLException;
import static org.junit.jupiter.api.Assertions.*;

public class ConexionMySQLTest {

    @Test
    public void testConectarYDesconectar() {
        ConexionMySQL conexion = new ConexionMySQL("root", "", "nextsport");

        assertDoesNotThrow(() -> {
            conexion.conectar();
            Connection conn = conexion.getConnection();
            assertNotNull(conn);
            assertFalse(conn.isClosed());
            conexion.desconectar();
            assertTrue(conn.isClosed());
        });
    }

    @Test
    public void testConexionFallida() {
        ConexionMySQL conexion = new ConexionMySQL("usuario_incorrecto", "clave", "basedatos");

        Exception exception = assertThrows(SQLException.class, conexion::conectar);
        assertTrue(exception.getMessage().contains("Error"));
    }
}
